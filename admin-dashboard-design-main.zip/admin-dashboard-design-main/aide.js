document.getElementById('email-link').addEventListener('click', function () {
    window.location.href = 'mailto:adbenatik@gmail.com';
});
